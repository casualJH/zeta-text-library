제타 텍스트 보관함 - 디시인사이드 지원 테스트판 (v1.0.1)

포함 파일: zeta-text-library-dcinside.user.js

지원 사이트:
- https://zeta-ai.io/
- https://m.dcinside.com/mini/zetaw 및 해당 갤러리 게시글
- https://gall.dcinside.com/mini/board/lists/?id=zetaw 및 해당 갤러리 게시글

변경 사항: Tampermonkey 허용 사이트 추가, 디시인사이드 타 갤러리 실행 방지.
기존 보관함 저장 키와 기능 코드 유지.

참고: 동일한 Tampermonkey 환경에서 기존 스크립트와 같은 이름/namespace를 사용합니다. 설치 전에 JSON 백업을 권장합니다.
이 버전은 테스트용이며 GitHub main 브랜치의 정식 1.0.0을 변경하지 않습니다.
